<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style/style.css" type="text/css"/>
    <link rel="icon" href="./img/icon.jpg"" sizes="32x32" />
    <link rel="icon" href="./img/icon.jpg" sizes="192x192" />
    <link rel="apple-touch-icon-precomposed" href="./img/icon.jpg" />
    <meta name="msapplication-TileImage" content="./img/icon.jpg" />
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">   
    <title>Portfolio | Owsky </title>
</head>
<body>
    <div class="hero_section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-ms-12 col-xs-12">
                    <h3>Hello!</h3>
                    <h1>I<span style="color: #f87652;">'</span> -/Owsky</h1>
                    <h2>Learn To Achieve Dreams</h2>
                    <p>I come from Indonesia. A young man who has a dream to become DevOps. It might seem silly, because I'm not very Coding savvy either. 
                    But I'm sure that I can reach my goals</p>
                    <div class="btn_container">
                        <a href="./portfolio/index.html"><button class="btn btn-light animate__animated">Click Here</button></a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-ms-12 col-xs-12">
                    <center>
                        <img src="https://i.ibb.co/gM05MK1/Picsart-23-06-10-01-59-29-949.jpg" alt="">
                    </center>
                </div>
            </div>
        </div>
    </div>
    <div id="particles-js"></div>
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <script>
        particlesJS.load('particles-js', 'particles.json',
        function(){
            console.log('particles.json loaded...')
        })
    </script>   
    <script type="text/javascript" src="./js/app.js"></script>
    <script type="text/javascript" src="./js/particles.js"></script>

</body>
</html>
                                                          
